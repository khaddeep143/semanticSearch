from pymilvus import connections, CollectionSchema, Collection, utility

CLUSTER_ENDPOINT = "http://localhost:19530"  # Set your cluster endpoint

# CLUSTER_ENDPOINT = "https://in03-6d2832adc9eb034.api.gcp-us-west1.zillizcloud.com"  # Set your cluster endpoint
# TOKEN = "e955eb2ca466825d0f7b8438db340c8295687e283dda8fc2925086373a55e368040d99cc163f5e354a36196f12a64fc686bfd82d"  # Set your token


class MilvusConfig:

    def __init__(self):
        self.cluster = self

    @staticmethod
    def establish_connection():
        connections.connect(alias='default', uri=CLUSTER_ENDPOINT)

    @staticmethod
    def collection(fields, collection_name):
        schema = CollectionSchema(fields, description="Schema of Medium articles",
                                  enable_dynamic_field=True)
        collection = Collection(name=collection_name, schema=schema)
        return collection

    @staticmethod
    def load_progress(collection_name):
        progress = utility.loading_progress(collection_name)
        print(progress)
