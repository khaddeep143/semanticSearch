import json

from flask import Flask, request
from sentence_transformers import SentenceTransformer
from waitress import serve
from semantic_text_splitter import TiktokenTextSplitter

from MilvusConfig import MilvusConfig
from DocumentData import DocumentData

COLLECTION_NAME = "crypto_collection"  # Set your collection name
words_to_remove = ["is", "a", "."]

app = Flask(__name__)


def vec_embeddings(text):
    embed_model = SentenceTransformer("e5-small-v2-fine-tuned")
    return embed_model.encode(text)


def parse_paragraphs():
    with open('DataRepository/high-performance-rag/doc-1.json') as json_file:
        data = json.load(json_file)
        paragraph_contents = [paragraph["content"] for paragraph in data.get("paragraphs", [])]
        return paragraph_contents


def load_corpus_from_json(para):
    max_characters = 50
    splitter = TiktokenTextSplitter("gpt-3.5-turbo", trim_chunks=True)
    chunks = splitter.chunks(para, max_characters)
    print(chunks)
    return chunks


@app.route('/insert', methods=['POST'])
def insert_data():
    MilvusConfig.establish_connection()
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    index_params = {
        "index_type": "AUTOINDEX",
        "metric_type": "L2",
        "params": {}
    }

    collection.create_index(field_name="chunk_text_vec", index_params=index_params, index_name='chunk_vector_index')
    collection.load()
    MilvusConfig.load_progress(COLLECTION_NAME)
    paragraphs_list = parse_paragraphs()

    for para in paragraphs_list:
        for node in load_corpus_from_json(para):
            chunk_text = node
            collection.insert({
                'doc_id': 1,
                'chunk_text_vec': vec_embeddings(node),
                'chunk_metadata': json.loads(json.dumps({"word": remove_unwanted_words(chunk_text)})),
                'paragraph_text': para,
                'chunk_text': node,
                'doc_url': 'test.com/2',
                'responses': 1})
        collection.flush()
    print(f"Data inserted successfully!")
    return "COMPLETED"


@app.route('/search', methods=['POST'])
def search():
    MilvusConfig.establish_connection()
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    keyword = request.args.get('keyword')
    search_params = {"metric_type": "L2"}

    filter_json = "JSON_CONTAINS_ANY(chunk_metadata['word']," + str(split_keywords(keyword)) + ")"
    print(filter_json)
    results = collection.search(
        data=[vec_embeddings(keyword)],
        anns_field="chunk_text_vec",
        param=search_params,
        expr=filter_json,
        output_fields=["chunk_id", "doc_id", "paragraph_text", "chunk_metadata", "doc_url"],
        limit=5
    )

    distances = results[0].distances

    print(distances)

    entities = [x.entity.to_dict()["entity"] for x in results[0]]
    print(entities)
    return entities


def split_keywords(keyword):
    keyword_split = keyword.split(" ")
    return keyword_split


def remove_unwanted_words(sentence: str):
    # filtered_words = [word for word in word_tokenize(sentence.lower()) if word not in words_to_remove]
    filtered_words = sentence.lower().split()
    return filtered_words


if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5000)
