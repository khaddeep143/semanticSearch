from pymilvus import FieldSchema, DataType


class DocumentData:

    def __init__(self):
        self.fields = self

    @staticmethod
    def Fields():
        fields = [
            FieldSchema(name="chunk_id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="doc_id", dtype=DataType.INT64, is_primary=False),
            FieldSchema(name="chunk_text_vec", dtype=DataType.FLOAT_VECTOR, dim=384),
            FieldSchema(name="chunk_metadata", dtype=DataType.JSON),
            FieldSchema(name="paragraph_text", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="chunk_text", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="doc_url", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="responses", dtype=DataType.INT64)
        ]
        return fields
