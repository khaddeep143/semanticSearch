import json

from flask import Flask, request
from llama_index import Document
from llama_index.embeddings import HuggingFaceEmbedding
from llama_index.node_parser import SentenceSplitter
from nltk import word_tokenize
from waitress import serve

from MilvusConfig import MilvusConfig
from DocumentData import DocumentData

COLLECTION_NAME = "crypto_collection"  # Set your collection name
words_to_remove = ["is", "a", "."]

app = Flask(__name__)


def vec_query_embeddings(text):
    embed_model = HuggingFaceEmbedding(model_name="e5-small-v2-fine-tuned")
    return embed_model.get_query_embedding(text)


def vec_embeddings(text):
    embed_model = HuggingFaceEmbedding(model_name="e5-small-v2-fine-tuned")
    return embed_model.get_text_embedding(text)


def parse_paragraphs():
    with open('DataRepository/high-performance-rag/doc-1.json') as json_file:
        data = json.load(json_file)
        paragraph_contents = [paragraph["content"] for paragraph in data.get("paragraphs", [])]
        return paragraph_contents


def load_corpus_from_json(para):
    documents_list = []
    documents_list.append(Document(text=para))
    node_parser = SentenceSplitter(chunk_size=50, chunk_overlap=0)
    nodes = node_parser.get_nodes_from_documents(documents_list, show_progress=True)
    print(nodes[0].get_content())
    print(f"Parsed {len(nodes)} nodes")

    return nodes


@app.route('/insert', methods=['POST'])
def insert_data():
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    index_params = {
        "index_type": "AUTOINDEX",
        "metric_type": "L2",
        "params": {}
    }

    collection.create_index(field_name="chunk_text_vec", index_params=index_params, index_name='chunk_vector_index')
    collection.load()
    MilvusConfig.load_progress(COLLECTION_NAME)
    insert_count: int = 0
    paragraphs_list = parse_paragraphs()

    for para in paragraphs_list:
        for node in load_corpus_from_json(para):
            chunk_text = node.get_content()
            results = collection.insert({
                'doc_id': 1,
                'chunk_text_vec': vec_embeddings(node.get_content()),
                'chunk_metadata': json.loads(json.dumps({"word": remove_unwanted_words(chunk_text)})),
                'paragraph_text': para,
                'chunk_text': node.get_content(),
                'doc_url': 'test.com/2',
                'responses': 1})
        collection.flush()
        insert_count += results.insert_count
        print(f"Data inserted successfully! Upstarted rows: {insert_count}")
    return "COMPLETED"


@app.route('/search', methods=['POST'])
def search():
    collection = MilvusConfig.collection(DocumentData.Fields(), collection_name=COLLECTION_NAME)
    keyword = request.args.get('keyword')
    search_params = {"metric_type": "L2"}

    filter_json = "JSON_CONTAINS_ANY(chunk_metadata['word']," + str(split_keywords(keyword)) + ")"
    print(filter_json)
    results = collection.search(
        data=[vec_query_embeddings(keyword)],
        anns_field="chunk_text_vec",
        param=search_params,
        expr=filter_json,
        output_fields=["chunk_id", "doc_id", "paragraph_text", "chunk_metadata", "doc_url"],
        limit=2
    )

    distances = results[0].distances

    print(distances)

    entities = [x.entity.to_dict()["entity"] for x in results[0]]
    print(entities)
    return entities


def split_keywords(keyword):
    keyword_split = keyword.split(" ")
    return keyword_split


def remove_unwanted_words(sentence: str):
    filtered_words = [word for word in word_tokenize(sentence.lower()) if word not in words_to_remove]
    return filtered_words


if __name__ == '__main__':
    MilvusConfig.establish_connection()
    serve(app, host='0.0.0.0', port=261)
