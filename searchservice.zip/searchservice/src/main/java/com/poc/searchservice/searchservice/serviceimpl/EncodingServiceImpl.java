package com.poc.searchservice.searchservice.serviceimpl;

import com.poc.searchservice.searchservice.service.EncodingService;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EncodingServiceImpl implements EncodingService {
    /**
     * Converts text to vector
     *
     * @param embeddingModel embedding model
     * @param text           knowledge or user query
     * @return vectors as a list
     */
    @Override
    public List<Float> encode(EmbeddingModel embeddingModel, String text) {
        if (embeddingModel != null & text != null && !text.isEmpty()) {
            TextSegment textSegment = TextSegment.from(text);
            return embeddingModel
                    .embed(textSegment)
                    .content()
                    .vectorAsList();
        } else {
            return null;
        }
    }

    /**
     * Converts text to vector
     *
     * @param embeddingModel embedding model
     * @param textSegment
     * @return vectors as a list
     */
    @Override
    public List<Float> encode(EmbeddingModel embeddingModel, TextSegment textSegment) {
        if (embeddingModel != null & textSegment != null && !textSegment.text().isEmpty()) {
            return embeddingModel
                    .embed(textSegment)
                    .content()
                    .vectorAsList();
        } else {
            return null;
        }
    }
}
