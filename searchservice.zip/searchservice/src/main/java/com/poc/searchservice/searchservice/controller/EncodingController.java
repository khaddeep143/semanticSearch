package com.poc.searchservice.searchservice.controller;

import com.poc.searchservice.searchservice.service.EncodingService;
import dev.langchain4j.model.embedding.E5SmallV2EmbeddingModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/searchService")
public class EncodingController {

    @Autowired
    private EncodingService encodingService;

    @PostMapping("/encode")
    public List<Float> getVectorList(@RequestBody String text) {
        return encodingService.encode(new E5SmallV2EmbeddingModel(), text);
    }

}
