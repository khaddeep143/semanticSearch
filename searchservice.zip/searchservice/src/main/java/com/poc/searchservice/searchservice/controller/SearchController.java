package com.poc.searchservice.searchservice.controller;

import com.poc.searchservice.searchservice.ResponseModel.SearchData;
import com.poc.searchservice.searchservice.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/searchService")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @GetMapping("/vectorSearch")
    public List<SearchData> vectorSearch(@RequestParam String keywords) {
        System.out.println("Inside Controllers earchResultsR");
        return searchService.vectorSearch(keywords);
    }

    @GetMapping("/search")
    public List<SearchData> search(@RequestParam String exactSearch,@RequestParam String keywords) {
        System.out.println("Inside Controllers earchResultsR");

        return  searchService.hybridSearch(keywords,exactSearch);
    }

}
