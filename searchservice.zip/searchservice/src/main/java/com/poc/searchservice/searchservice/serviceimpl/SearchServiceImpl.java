package com.poc.searchservice.searchservice.serviceimpl;

import com.poc.searchservice.searchservice.ResponseModel.SearchData;
import com.poc.searchservice.searchservice.service.EncodingService;
import com.poc.searchservice.searchservice.service.SearchService;
import dev.langchain4j.model.embedding.AllMiniLmL6V2EmbeddingModel;
import dev.langchain4j.model.embedding.E5SmallV2EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiEmbeddingModel;
import io.milvus.client.MilvusServiceClient;
import io.milvus.common.clientenum.ConsistencyLevelEnum;
import io.milvus.grpc.DataType;
import io.milvus.grpc.SearchResultData;
import io.milvus.grpc.SearchResults;
import io.milvus.param.*;
import io.milvus.param.collection.FieldType;
import io.milvus.param.dml.QueryParam;
import io.milvus.param.dml.SearchParam;
import io.milvus.response.QueryResultsWrapper;
import io.milvus.response.SearchResultsWrapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
//import org.apache.lucene.search.similarities;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class SearchServiceImpl implements SearchService {

    @Value("${dimension}")
    public int dim;
    @Value("${collection.name}")
    public String collectionName;

//    @Value("${pagination}")
    public String searchParams = "{\"nprobe\":0}";

    @Value("${topK}")
    public Integer searchK;

    @Autowired
    private MilvusServiceClient milvusServiceClient;

    @Autowired
    private EncodingService encodingService;

    @Override
    public List<SearchData> hybridSearch(String keywords, String isExactSearch) {
        System.out.println("New Search::::search()");

        String expr_1 = "JSON_CONTAINS(article_meta[\"Figure\"])";

        FieldType docVector = FieldType.newBuilder()
                .withName("doc_text_vector")
                .withDataType(DataType.FloatVector)
                .withDimension(dim)
                .build();

        List<String> search_output_fields = Arrays.asList("sys_id", "doc_id", "doc_text");

        System.out.println("Input::::" + keywords);

        List<Float> vectorList = encodingService.encode(new AllMiniLmL6V2EmbeddingModel(), keywords);
//        List<Float> vectorList = encodingService.encode(new E5SmallV2EmbeddingModel(), keywords);

//        List<Float> vectorList = encodingService.encode(OpenAiEmbeddingModel.withApiKey("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"), keywords);
        List<List<Float>> search_vectors = Collections.singletonList(vectorList);

        SearchParam searchParam = SearchParam.newBuilder()
                .withCollectionName(collectionName)
                .withMetricType(MetricType.COSINE)
                .withOutFields(search_output_fields)
                .withConsistencyLevel(ConsistencyLevelEnum.STRONG)
                .withTopK(searchK)
                .withVectors(search_vectors)
                .withVectorFieldName(docVector.getName())
                .withParams(searchParams)
//                .withExpr(expr_1)
                .build();

        R<SearchResults> search = milvusServiceClient.search(searchParam);

        SearchResultData searchResultData = search.getData().getResults();

        return searchData(searchResultData, keywords, isExactSearch);
    }

    @Override
    public List<SearchData> vectorSearch(String keywords) {
        System.out.println("New Search::::search()");
        FieldType docVector = FieldType.newBuilder()
                .withName("doc_text_vector")
                .withDataType(DataType.FloatVector)
                .withDimension(dim)
                .build();

        List<String> search_output_fields = Arrays.asList("sys_id", "doc_id", "doc_text");

        System.out.println("Input::::" + keywords);


//        List<Float> vectorList = encodingService.encode(new AllMiniLmL6V2EmbeddingModel(), keywords);
//        List<Float> vectorList = encodingService.encode(new E5SmallV2EmbeddingModel(), keywords);

        List<Float> vectorList = encodingService.encode(OpenAiEmbeddingModel.withApiKey("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"), keywords);
        List<List<Float>> search_vectors = Collections.singletonList(vectorList);

        SearchParam searchParam = SearchParam.newBuilder()
                .withCollectionName(collectionName)
                .withMetricType(MetricType.COSINE)
                .withOutFields(search_output_fields)
                .withConsistencyLevel(ConsistencyLevelEnum.STRONG)
                .withTopK(searchK)
                .withVectors(search_vectors)
                .withVectorFieldName(docVector.getName())
                .withParams(searchParams)
                .build();

        R<SearchResults> search = milvusServiceClient.search(searchParam);

        SearchResultData searchResultData = search.getData().getResults();

        return searchData(searchResultData, keywords, "false");
    }

    private List<SearchData> searchData(SearchResultData searchResultData, String keywords, String isExactSearch) {

        List<SearchData> searchDataArrayList = new ArrayList<>();

        System.out.println("Search Results::::" + searchResultData);

        List<Float> scoreList = searchResultData.getScoresList();
        System.out.println("New Search searchData()::::Fetched Successfully:::ScoreList" + scoreList);

        List<?> ids = getByFieldName(searchResultData, "sys_id");
        System.out.println("New Search searchData()::::Fetched Successfully:::ids" + ids);

        List<?> docIds = getByFieldName(searchResultData, "doc_id");
        System.out.println("New Search searchData()::::Fetched Successfully:::docIds" + docIds);

        List<?> docTexts = getByFieldName(searchResultData, "doc_text");
        System.out.println("New Search searchData()::::Fetched Successfully:::docTexts" + docTexts);

        System.out.println("New Search searchData()::::Fetched Successfully");

        System.out.println("Entered Inside Loop");
        for (int i = 0; i < searchK; i++) {
            SearchData searchData = new SearchData();
            String knowledgeText = docTexts.get(i).toString();

            if (Boolean.parseBoolean(isExactSearch)) {
                if (StringUtils.containsAnyIgnoreCase(knowledgeText,keywords.split(" "))) {
                    searchData.setSysId((Long) ids.get(i));
                    searchData.setDoc_id((Long) docIds.get(i));
                    searchData.setScore(scoreList.get(i));
                    searchData.setDoc_text(knowledgeText);

                    searchDataArrayList.add(searchData);
                }
            } else {
                searchData.setSysId((Long) ids.get(i));
                searchData.setDoc_id((Long) docIds.get(i));
                searchData.setScore(scoreList.get(i));
                searchData.setDoc_text(knowledgeText);

                searchDataArrayList.add(searchData);
            }
        }
        System.out.println("New Search searchData()::::Sending Data");
        return searchDataArrayList;
    }


    private List<?> getByFieldName(SearchResultData searchResultData, String fieldName) {
        SearchResultsWrapper wrapperSearch = new SearchResultsWrapper(searchResultData);
        return wrapperSearch.getFieldData(fieldName, 0);
    }

}
