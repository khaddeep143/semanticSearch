package com.poc.searchservice.searchservice.service;


import io.milvus.grpc.DescribeCollectionResponse;
import org.springframework.http.ResponseEntity;

public interface KnowledgeBaseService {

    ResponseEntity<String> connectivity(String collectionName);

    DescribeCollectionResponse describeCollectionResponse();

    void createIndex(int waitIntervalInMilliSeconds, int timeOutInSeconds, String fieldName, String collectionName);

    void upsert(String text);

    void flush(long waitIntervalInMilliSeconds, long timeOutInSeconds);
}
